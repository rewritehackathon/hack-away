﻿using HackAwayDAL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace HackAwayDAL
{
    public class HackAwayRepository
    {
        InsuranceCoverageContext context;

        public HackAwayRepository()
        {
            context = new InsuranceCoverageContext();
        }
        //Add Purchase to CoveragedPurchased Table
        public bool AddInsurancePurchase(int userID,int coverageID)
        {
            CoveragePurchased purchased = new CoveragePurchased
            {
                UserId = userID,
                CoverageId = coverageID
            };

            bool status;
            try
            {
                context.CoveragePurchased.Add(purchased);
                context.SaveChanges();
                status = true;
            }
            catch
            {
                status = false;
            }
            return status;

        }
        //Add user to User Info Table
        public int AddUser(int zipCode)
        {
            UserInfo user = new UserInfo { ZipCode = zipCode };
            int userId;
            try
            {
                context.UserInfo.Add(user);
                context.SaveChanges();
                userId = user.UserId;
                
            }
            catch
            {
                userId = 0;
            }
            return userId;
        }
        //get list of all coverages in the database
        public List<string> Coverages(int zipCode)
        {
            List<string> typesGeo;
            List<string> typesUser;
            List<string> types;

            try
            {
                typesGeo = (from coverage in context.GeoBasedCoverage
                         join type in context.TypesOfCoverage on coverage.CoverageId equals type.CoverageId
                         select type.TypeOfCoverage).Distinct().ToList();
                typesUser= (from coverage in context.CoveragePurchased
                            join type in context.TypesOfCoverage on coverage.CoverageId equals type.CoverageId
                            join user in context.UserInfo on coverage.UserId equals user.UserId
                            select type.TypeOfCoverage).Distinct().ToList();
               typesGeo.AddRange(typesUser);
               types = typesGeo
                   .Distinct()
                   .ToList();
            }
            catch
            {
                types = null;
            }
            return types;
        }
        //get the percentage of users who purchased that type of coverage based on zip code
        public double getUsersWhoPurchased(string typeOfCoverage, int zipCode)
        {
            double numberOfUsersWith = (from user in context.CoveragePurchased
                                     join zip in context.UserInfo on user.UserId equals zip.UserId
                                     join type in context.TypesOfCoverage on user.CoverageId equals type.CoverageId
                                     where zip.ZipCode == zipCode && type.TypeOfCoverage.ToLower() == typeOfCoverage.ToLower()
                                     select user).Count();
            double numberofUsersTotal = (from user in context.CoveragePurchased
                                      join zip in context.UserInfo on user.UserId equals zip.UserId
                                      where zip.ZipCode == zipCode
                                      select user).Count();
            double percentage;
            if (numberOfUsersWith == 0 || numberofUsersTotal == 0)
                percentage = 0;
            else
                percentage = numberOfUsersWith / numberofUsersTotal *100;
            return percentage;
        }
        //Gets the risk of environmental factors from the GeoBased Coverage
        public int geoRisk(string typeOfCoverage,int zipCode)
        {
            int risk;
            var riskList = (from riskGeo in context.GeoBasedCoverage
                                       join type in context.TypesOfCoverage on riskGeo.CoverageId equals type.CoverageId
                                       where riskGeo.ZipCode == zipCode && type.TypeOfCoverage == typeOfCoverage
                                       select riskGeo.RiskLevel);
            if (riskList.Count() == 0)
                risk = 0;
            else
                risk = riskList.First();

            return risk;
        }
        
        public int getCoverageId(string typeOfCoverage)
        {
            int coverageId;
            var coverageList = from coverage in context.TypesOfCoverage
                               where coverage.TypeOfCoverage.ToLower() == typeOfCoverage
                               select coverage.CoverageId;
            coverageId = coverageList.First();
            return coverageId;
        }


    }
}
