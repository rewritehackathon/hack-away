﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace HackAwayDAL.Models
{
    public partial class InsuranceCoverageContext : DbContext
    {
        public InsuranceCoverageContext()
        {
        }

        public InsuranceCoverageContext(DbContextOptions<InsuranceCoverageContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CoveragePurchased> CoveragePurchased { get; set; }
        public virtual DbSet<GeoBasedCoverage> GeoBasedCoverage { get; set; }
        public virtual DbSet<TypesOfCoverage> TypesOfCoverage { get; set; }
        public virtual DbSet<UserInfo> UserInfo { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source = USABOS273517L\\SQLEXPRESS;Initial Catalog=InsuranceCoverage;Integrated Security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.3-servicing-35854");

            modelBuilder.Entity<CoveragePurchased>(entity =>
            {
                entity.HasKey(e => e.PurchasedId)
                    .HasName("PK__Coverage__2B7C245CE527BD96");

                entity.Property(e => e.PurchasedId).HasColumnName("PurchasedID");

                entity.Property(e => e.CoverageId).HasColumnName("CoverageID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.HasOne(d => d.Coverage)
                    .WithMany(p => p.CoveragePurchased)
                    .HasForeignKey(d => d.CoverageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_TOCPID");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.CoveragePurchased)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_UserID");
            });

            modelBuilder.Entity<GeoBasedCoverage>(entity =>
            {
                entity.HasKey(e => e.GeoCoverageId)
                    .HasName("pk_GeoCoverageID");

                entity.Property(e => e.GeoCoverageId).HasColumnName("GeoCoverageID");

                entity.Property(e => e.CoverageId).HasColumnName("CoverageID");

                entity.Property(e => e.ZipCode).HasColumnType("numeric(5, 0)");

                entity.HasOne(d => d.Coverage)
                    .WithMany(p => p.GeoBasedCoverage)
                    .HasForeignKey(d => d.CoverageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_CoverageID");
            });

            modelBuilder.Entity<TypesOfCoverage>(entity =>
            {
                entity.HasKey(e => e.CoverageId)
                    .HasName("pk_CoverageID");

                entity.Property(e => e.CoverageId).HasColumnName("CoverageID");

                entity.Property(e => e.CoverageDescription)
                    .IsRequired()
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfCoverage)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserInfo>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("pk_UserID");

                entity.Property(e => e.UserId).HasColumnName("UserID");

                entity.Property(e => e.ZipCode).HasColumnType("numeric(5, 0)");
            });
        }
    }
}
