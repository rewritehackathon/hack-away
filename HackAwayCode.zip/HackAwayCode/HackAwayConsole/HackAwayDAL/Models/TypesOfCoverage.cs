﻿using System;
using System.Collections.Generic;

namespace HackAwayDAL.Models
{
    public partial class TypesOfCoverage
    {
        public TypesOfCoverage()
        {
            CoveragePurchased = new HashSet<CoveragePurchased>();
            GeoBasedCoverage = new HashSet<GeoBasedCoverage>();
        }

        public int CoverageId { get; set; }
        public string TypeOfCoverage { get; set; }
        public string CoverageDescription { get; set; }

        public virtual ICollection<CoveragePurchased> CoveragePurchased { get; set; }
        public virtual ICollection<GeoBasedCoverage> GeoBasedCoverage { get; set; }
    }
}
