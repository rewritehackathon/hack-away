﻿using System;
using System.Collections.Generic;

namespace HackAwayDAL.Models
{
    public partial class UserInfo
    {
        public UserInfo()
        {
            CoveragePurchased = new HashSet<CoveragePurchased>();
        }

        public int UserId { get; set; }
        public decimal ZipCode { get; set; }

        public virtual ICollection<CoveragePurchased> CoveragePurchased { get; set; }
    }
}
