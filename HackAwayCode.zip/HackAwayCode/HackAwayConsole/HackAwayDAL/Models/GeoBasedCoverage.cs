﻿using System;
using System.Collections.Generic;

namespace HackAwayDAL.Models
{
    public partial class GeoBasedCoverage
    {
        public int GeoCoverageId { get; set; }
        public decimal ZipCode { get; set; }
        public int CoverageId { get; set; }
        public int RiskLevel { get; set; }

        public virtual TypesOfCoverage Coverage { get; set; }
    }
}
