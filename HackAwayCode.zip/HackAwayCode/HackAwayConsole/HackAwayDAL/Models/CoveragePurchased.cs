﻿using System;
using System.Collections.Generic;

namespace HackAwayDAL.Models
{
    public partial class CoveragePurchased
    {
        public int PurchasedId { get; set; }
        public int UserId { get; set; }
        public int CoverageId { get; set; }

        public virtual TypesOfCoverage Coverage { get; set; }
        public virtual UserInfo User { get; set; }
    }
}
