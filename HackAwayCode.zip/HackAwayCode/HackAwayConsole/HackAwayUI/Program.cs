﻿using HackAwayDAL;
using HackAwayDAL.Models;
using System;
using System.Collections.Generic;

namespace HackAwayUI
{
    class Program
    {
        static HackAwayRepository dal;

        static Program()
        {
            dal = new HackAwayRepository();
        }
        static void Main(string[] args)
        {
            string userZipCode;
            int userZip;
            Console.OutputEncoding = System.Text.Encoding.Unicode;
            Console.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~HackAway~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            Console.WriteLine();
            Console.WriteLine("Please enter your zipcode");
            userZipCode = Console.ReadLine();
            userZip = Convert.ToInt32(userZipCode);
            Console.WriteLine();
            Console.WriteLine("Based on the given zipcode, these are our recommendations:");

            Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("{0,-30}{1,-6}{2,-30}{3,-4}{4,-30}{5}{6,-45}{7,-16}", "Type of Coverage","|", "Based on Geographical Data", "|", "Based on Other Users", "|", "% of Users Who Purchased This Coverage in the Area","|");
            Console.WriteLine("-------------------------------------------------------------------------------------------------------------------------------------------------------");
            List<string> coverageList = dal.Coverages(userZip);
            foreach(var type in coverageList)
            {
                
                Console.Write("{0,-30}{1,-6}",type,"|");
                double percentage = dal.getUsersWhoPurchased(type, userZip);
                int riskLevel = dal.geoRisk(type, userZip);

                

                if (riskLevel < 5)
                    Console.Write("{0,-30}{1,-4}", "X", "|");
                else
                    Console.Write("{0,-30}{1,-4}", "\u221A", "|");
                if (percentage < 50)
                    Console.Write("{0,-30}{1}", "X", "|");
                else
                    Console.Write("{0,-30}{1}", "\u221A", "|");

                Console.Write("{0,-50}{1}",percentage.ToString("0.##"), "|");

                Console.WriteLine();
                
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Which would coverage(s) you like to apply? Enter E to exit.");
            string text = Console.ReadLine().ToLower();

            int userId = dal.AddUser(userZip);
            int coverageId;
            while (text != "E".ToLower())
            {
                coverageId = dal.getCoverageId(text);
                dal.AddInsurancePurchase(userId, coverageId);
                text = Console.ReadLine().ToLower();

            }

        }
    }
}
